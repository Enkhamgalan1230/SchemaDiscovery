"""
Unary UCC discovery.

UCC = Unique Column Combination.
Unary: a single column is unique (and typically non-null).

This module extracts unary UCC candidates from the profiling output.
These candidates are later used as possible referenced keys when searching
for relationships (INDs) between tables.

This module does not choose a primary key. It only returns candidates.
"""

from __future__ import annotations

import pandas as pd


def discover_ucc_unary(
    profiles_df: pd.DataFrame,
    unique_ratio_min: float = 1.0,
    null_ratio_max: float = 0.0,
    use_flag_if_present: bool = True,
) -> pd.DataFrame:
    """
    Return unary UCC candidates from a profiles DataFrame.

    A column is considered a unary UCC candidate if:
      - unique_ratio >= unique_ratio_min
      - null_ratio   <= null_ratio_max
 
    If profiling provides `is_unary_ucc` and use_flag_if_present=True,
    that flag is used as an additional fast path signal.
    """
    required = {
        "table_name",
        "column_name",
        "dtype_family",
        "n_rows",
        "unique_ratio",
        "null_ratio",
    }
    missing = required - set(profiles_df.columns)
    if missing:
        raise ValueError(f"profiles_df missing required columns: {sorted(missing)}")

    df = profiles_df.copy()

    mask = (df["unique_ratio"] >= unique_ratio_min) & (df["null_ratio"] <= null_ratio_max)

    if use_flag_if_present and "is_unary_ucc" in df.columns:
        # If strict mode is requested, the flag is consistent with strict thresholds.
        # If relaxed thresholds are used, we still keep the ratio-based rule.
        mask = mask | (df["is_unary_ucc"].astype(bool))

    ucc = df.loc[mask, ["table_name", "column_name", "dtype_family", "n_rows", "unique_ratio", "null_ratio"]].copy()
    ucc["ucc_type"] = "unary"

    return ucc.sort_values(["table_name", "column_name"], kind="mergesort").reset_index(drop=True)
